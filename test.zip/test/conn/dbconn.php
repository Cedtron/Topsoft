<?php
$servename="localhost";
$user = "root";
$password = ""; 
$database = "omega";
$conn = new mysqli($servename, $user, $password, $database);
?>